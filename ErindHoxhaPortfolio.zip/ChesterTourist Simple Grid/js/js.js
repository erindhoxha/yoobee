
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}


    $(document).ready(function() {
      // Initialize the plugin
      $('#my_popup').popup();
    });

$(".activities-button").click(function() {
	$(".nightlife").hide();
});


$(document).ready(function() {
    $("select,input").change(function() {
        // my code and some alerts
    });

    // more code here if needed, etc.
});
